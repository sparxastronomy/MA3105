function a_0 = NR(x_0, max_itr, tol, alpha)
    clc;
    
    nr = f(x_0);
    dr = der_f(x_0);
  
    %saveing roots
    a_0 = NaN(max_itr,1); %initializing
    a_0(1) = x_0;
    a_0(2) = x_0 - (nr/dr);
    
    fprintf(' n \t\t a_o \t\t\t f(a_0) \t\t (a_0 - x_0) \t  rel_err \n')
    fprintf('======================================================================\n')
    for i=1:max_itr
        %checking for error
        err = a_0(i+1) - a_0(i);
        rel_err = err/alpha;
        fprintf('%2i \t\t %f \t\t %f \t\t %f \t\t %f\n',i, a_0(i), nr, err, rel_err )
        
        if abs(err)<tol
            %index for triming the NaN array
            break_idx = i;
            break
        end
        
        nr = f(a_0(i+1));
        dr = der_f(a_0(i+1));
        
        a_0(i+2) = a_0(i+1) - (nr/dr);
    end
    a_0 = a_0(1:break_idx);
end

 function val=f(x)
    %function
    val=x^6 -x -1;
 end
 
 function der=der_f(x)
    %derivative of f
    der = 6*x^5 - 1;
 end