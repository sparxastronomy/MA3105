%root finding using regula falsi method

function r = rf(x_0,x_1,max_itr, tol)
    clc;
    
    r = NaN(max_itr,1);
    r(1:2) = [x_0,x_1];
    
    fprintf('itr \t\t x_n+1 \t\t f(x_n+1) \t\t error\n')
    fprintf('====================================================\n')    
    for i=3:max_itr
        r(i) = x_1 - f(x_1)*((x_1 - x_0)/(f(x_1) - f(x_0)));
        err = r(i) - x_1;
        fprintf('%2i \t\t %f \t\t %f \t\t %f\n',i-2, r(i), f(r(i)), err )
        if abs(err)<tol
            break_idx = i;
            break;
        end
        
        if f(x_1)*f(r(i))<0
            x_1 = r(i);
        else
            x_0 = r(i);
        end
    end
    r = r(1:break_idx);
end

function val=f(x)
   %function
   val=x^6 -x -1;
end