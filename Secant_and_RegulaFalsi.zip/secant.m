function r = secant(x, max_itr, tol)
    clc;
    
    r = NaN(max_itr,1); %initializing
    r(1:2)=x;
    
    fprintf('itr \t\t x_n+1 \t\t f(x_n+1) \t\t error\n')
    fprintf('====================================================\n')
    for i=3:max_itr
        r(i) = r(i-1) - f(r(i-1))*((r(i-1) - r(i-2))/(f(r(i-1)) - f(r(i-2))));
        err = r(i) - r(i-1);
        
        fprintf('%2i \t\t %f \t\t %f \t\t %f\n',i-2, r(i), f(r(i)), err )
        if abs(err)<tol
            break_idx = i;
            break;
        end
        
    end
    r = r(1:break_idx);
end

function val=f(x)
   %function
   val=x^6 -x -1;
end
 