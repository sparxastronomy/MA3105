function m=bisection(low, high, m_itr, tol)
    s1 = sign(f(low));
    s2 = sign(f(high));
    
    %cheching if root exists
    if s1*s2 >0
        disp('No root exist in the given interval')
        m='Error';
        return
    end
    
    fprintf('Itr \t  low  \t\t  high \t\t   root \t\tdiff \t f_value \n')
    fprintf('======================================================================\n')
 
    for i=1:m_itr    
        %getting root
        m=(high+low)/2;
        
        s3 = sign(f(m));
        if s3==0
            fprintf("Root found at x= %f \n\n", m)
            return
        end
        
        fprintf('%2i \t\t %f \t %f \t %f \t %f \t %f \n', i, low, high, m, abs(m-high), f(m))
        
        %exiting if tolerence reached
        if abs(high-m)<tol
            break
        end
        %updating values
        if s1*s3>0
            low = m;
            s1 = s3;
        else
            high=m;
        end        
    end
    
end

 function val=f(x)
    val=x^6 -x -1;
 end


