%This scrpipt only shows pretty plots and prints final roots
%for t=detailed root calclulation use 'FixedPointItr_detail.m'
clc;
clear;
f1 = @(x) (10)./(x.^3 - 1);
f2 = @(x) (x+10).^(0.25);
f3 = @(x) ((x+10).^(0.5))./x ;

x = linspace(0.5,7);

fprintf("Estimating root for F1, x0=0.5\n")
f = f1(x);
subplot(1,3,1)
plot(x,f,'b-','LineWidth',2)
hold on
plot(x,x,'black-')
%getting the roots
[r1,v1] = fpi(0.5,f1,100, 0.0001);

l = length(r1);
if l<100
    fprintf("Converes within %i iterations and root is %f and f(x) %f\n\n", l,r1(l), v1(l))
else
    fprintf("Doesn't Converges, and final root is %f and f(x) %f\n\n", r1(l), v1(l))
end
xlabel("x",'interpreter', 'latex','FontSize', 18)
ylabel("f(x)",'interpreter', 'latex','FontSize', 18)
title("$10/(x^3 - 1)$",'interpreter', 'latex','FontSize', 20)
hold off


fprintf("Estimating root for F2, x0=0.5\n")
f = f2(x);
subplot(1,3,2)
plot(x,f,'b-','LineWidth',2)
hold on
plot(x,x,'black-')

%getting the roots
[r2,v2] = fpi(0.5,f2,100, 0.0001);
l = length(r2);
if l<100
    fprintf("Converes within %i iterations and root is %f and f(x) %f\n\n", l,r2(l), v2(l))
else
    fprintf("Doesn't Converges, and final root is %f and f(x) %f\n\n", r2(l), v2(l))
end
xlabel("x",'interpreter', 'latex','FontSize', 18)
ylabel("f(x)",'interpreter', 'latex','FontSize', 18)
title("${(x+10)^{0.25}}$",'interpreter', 'latex','FontSize', 20)
hold off


fprintf("Estimating root for F2, x0=0.5\n")
f = f3(x);
subplot(1,3,3)
plot(x,f,'b-','LineWidth',2)
hold on
plot(x,x,'black-')

%getting the roots
[r3,v3] = fpi(0.5,f3,100, 0.0001);
l = length(r3);
if l<100
    fprintf("Converes within %i iterations and root is %f and f(x) %f", l,r3(l), v3(l))
else
    fprintf("Doesn't Converges, and final root is %f and f(x) %f\n\n", r3(l), v3(l))
end
xlabel("x",'interpreter', 'latex','FontSize', 18)
ylabel("f(x)",'interpreter', 'latex','FontSize', 18)
title("${(x+10)^{0.5}}/{x}$",'interpreter', 'latex','FontSize', 20)
hold off




function [r,v] = fpi(x0,F,max_itr, tol)
    r = NaN(max_itr,1);
    v = NaN(max_itr,1);
    
    r(1) = x0;
    v(1) = F(x0);
    for i=2:max_itr
       r(i) = F(r(i-1));
       v(i) = F(r(i));
       %commands for plotting path followed by roots
       p1 = [r(i-1) r(i-1)]; p2 = [r(i-1) F(r(i-1))];           
       dp = (p2-p1)/2;
       quiver(p1(1),p1(2),dp(1),dp(2),0,'r-')
       plot(p1,p2,'r-')
       plot([r(i-1) F(r(i-1))],[r(i) r(i)],'r-')
       plot([r(i) r(i)],[r(i) F(r(i))],'r-')
       plot([r(i) F(r(i))],[F(r(i)) F(r(i))],'r-')
       
       err = r(i)-r(i-1);
       if abs(err)<tol
           break_idx = i;
           break;
       end
       if i==max_itr
           break_idx=i;
           break
       end
    end
    r = r(1:break_idx);
    v = v(1:break_idx);
end


