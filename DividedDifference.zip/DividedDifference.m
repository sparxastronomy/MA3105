clc; clear;

x = 0:0.2:1.2;
y = cos(x);

plot(x,y, 'red')
hold on

% values where the interpolation needs to be done
x_i = [0.1, 0.3, 0.5];

%getting the table
Table = get_TDD(x,y);

%calualting intrpolated values:
fprintf("Order \t%f \t %f \t %f\n",x_i(1), x_i(2), x_i(3))
fprintf("==========================================\n")
for i = 1:length(x)
    values = get_DD_values(Table,x,x_i,i);
    if i ==length(x)
        scatter(x_i, values, 'filled', 'blue')
    end
end

xlabel("x", 'interpreter', 'latex','FontSize', 18)
ylabel("Y", 'interpreter', 'latex','FontSize', 18)
legend({'$y=cos(x)$', 'Interpolated Value of highest order'}, 'Location','southwest','interpreter', 'latex','FontSize', 14)
title("Newton's Divided Difference Interpolation", 'FontSize', 14)
hold off


% Required Functions
function TDD = get_TDD(X,Y)
    % function to get divided difference table
    [ p, m ] = size(X); 
    if p ~= 1 || p ~=size(Y, 1) || m ~= size(Y, 2)
        error('Error: input vectors must have the same dimension'); 
    end
    
    TDD = zeros(m, m);
    
    TDD(:, 1) = Y';
    for j = 2 : m
        for i = 1 : (m - j + 1)
            TDD(i,j) = (TDD(i + 1, j - 1) - TDD(i, j - 1)) / (X(i + j - 1) - X(i));
        end
    end
    fprintf("Printing Divided difference table:\n")
    TDD
end

function val = get_DD_values(TDD, X, X_i, O)
    % Gets interpolated values from the provided table of divided
    % difference
    [i,j] = size(TDD);
    p = length(X_i);
    
    val = zeros(1,3);
        
        for l=1:p
            y_eval = 0;
            p =1;
            for k = 1:O
                y_eval = y_eval + p*TDD(1,k);
                p = p*(X_i(l)- X(k));        
            end
            val(l) = y_eval;
        end
        
        fprintf("P_%i \t %f \t %f \t %f\n",O-1, val(1),val(2), val(3));
end