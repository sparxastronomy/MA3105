% numerical solutions to ODE using Euler method
clc;
clear;

%% Defining functions and solution
% problem 1
f1 = @(x,y) y;
f1_sol = @(x) exp(x);

% problem 2
f2 = @(x,y) (1/(1+x^2) - 2*y^2);
f2_sol = @(x) x./(1+x.^2);

%defining steping array 
h_ar = [0.05, 0.1, 0.2];

%% getting the solution for first ode
fprintf("Problem 1\n\n")

% plotting true solution
figure(1)
x_plot = 0:0.1:5;
plot(x_plot, f1_sol(x_plot),"red","LineWidth",1.3, ...
    'DisplayName',"Analytical~Solution: $y=e^x$")
hold on

% getting numerical solutions for diffent step size
for i=1:3
    sol = euler_ode(f1, f1_sol, 0, 1, h_ar(i), 5, [1,2,3,4,5]);
end
title("ODE: $y'(x) = y(x)$", ...
    Interpreter="latex",FontSize=16)
hold off % stop plotting for this section

%% getting the solution for second ode
fprintf("\n\n________________________________________________\n")
fprintf("Problem 2\n")

% plotting true solution
figure(2)
x_plot = 0:0.1:5;
plot(x_plot, f2_sol(x_plot),"red","LineWidth",1.3, ...
    'DisplayName',"Analytical Solution: $y = {x}/(1+x^2)$")
hold on

% getting numerical solutions for diffent step size
for i=1:3
    sol = euler_ode(f2, f2_sol, 0, 0, h_ar(i), 5, [1,2,3,4,5]);
end

title("ODE: $y'(x) = \frac{1}{1+x^2}-2y$", ...
    "Interpreter","latex","FontSize",16)
hold off % stop plotting for this section



%% Function definition for Euler method of solving ODE
function y = euler_ode(f,f_sol,x0,y0,h,x_end,x_disp)
    % parameters required are
    % f     : RHS of the ODE equation
    % f_sol : true solution of ODE
    % x0,y0 : Inital values
    % h     : Stepping size
    % x_end : end ponint of the domain i.e [x0, x_end]
    % x_disp: Array of values for which the solution and error
    %         will be printed 


    x = x0:h:x_end; 
    y = NaN(length(x),1); %solution array
    y(1) = y0;
    t_idx = 1; %index to keep track of display elements

    fprintf("\nStep size = %2.2f\n",h)
    fprintf("   x(i)     y(i)\ttrue_err\t  rel_err\n")
    fprintf("   ======================================\n")
    for i=2:length(x)
        % implementing euler method
        y(i) = y(i-1) + h*f(x(i-1),y(i-1));    

        %for displaying the solutions at the given values
        if x(i)==x_disp(t_idx)
            rel_error = y(i)-y(i-1);
            true_error = f_sol(x(i)) - y(i);
            fprintf("%7.2f  %8.4f  %8.4f \t %8.4f\n", ...
                [x(i), y(i), rel_error, true_error])
            t_idx = t_idx+1;
        end
    end

    % plotting the solution
    plot(x,y, "LineWidth",1, ...
        'DisplayName',"Numerical Solution: h="+string(h))
    legend("Location","best","FontSize",14,"Interpreter","latex")    
end

