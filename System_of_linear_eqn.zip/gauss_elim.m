%gaussian elimination

function x = gauss_elim(A, b)
%% Create permutation vector
n = size(A, 1);  % Size of input matrix A
r = zeros(n, 1); % Initialize permutation vector
for i = 1 : 1 : n    
   r(i) = i;
end
%this permutaion vector will store the permuatations across rows 
%while doing the pivoting
%% Apply Gaussian elimination after doing pivoiting
x = zeros(n, 1); % Initializing solution vector
for k = 1 : 1 : n     
    % Compare each element in pivot column for the max
    max = abs(A(r(k), r(k)));    
    max_pos = k;    
    for l = k : 1 : n        
        if abs(A(r(l), r(k))) > max            
            max = abs(A(r(l), r(k)));            
            max_pos = l;            
        end
    end
    % Switching the kth r-vector element with max r-vector element  
    temp_r = r;
    r(k) = temp_r(max_pos);
    r(max_pos) = temp_r(k);
    % Eliminating A-vector elements in r-th column below r-th row        
    for i = 1 : 1 : n
        if i ~= k
            m = A(r(i), k) / A(r(k), k);
            for j = k : 1 : n
                A(r(i), j) = A(r(i), j) - A(r(k), j) * m;                       
            end
            b(r(i)) = b(r(i)) - b(r(k)) * m;
        end
    end
end

%% Computing solution from the reduced A-matrix
for i = 1 : 1 : n
    x(i) = b(r(i)) / A(r(i), i);
end
end