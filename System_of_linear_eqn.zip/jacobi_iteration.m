%Jacobi iteration method
clc;

A = [9 1 1; 2 10 3; 3 4 11];
B = [10 19 0]';
fprintf("Augumented matrix\n")
[A B]
sol = Gauss_seidel(A, B, [0 0 0]', 100, 0.00001);
fprintf("\n\nSolution using jacobi itrative Method:")
sol


function x = Gauss_seidel(A,b,x_init,max_itr,tol)
n = size(A,1);    
x = x_init; %inital guess
fprintf("\n\nItr \t\t\t x's \t\t   err\n")
fprintf("======================================\n")
fprintf("0    %4.2f \t\t %4.2f \t\t %4.2f\n",x(1), x(2), x(3))

for i=1:max_itr
    prev_itr = x;
    
    for j=1:n
        sum = b(j);
        for l=1:n
            if l~=j
                sum = sum - prev_itr(l)*A(j,l);
            end
        end
        x(j) = sum/A(j,j);
    end
    fprintf("%i\t",i)
    for k=1:n
        fprintf(" %4.6f ",x(k))
    end
    err = max(x-prev_itr);
    err = abs(err);
    fprintf(" %4.6f\n",err)
    if err<tol
        break
    end    
end
end