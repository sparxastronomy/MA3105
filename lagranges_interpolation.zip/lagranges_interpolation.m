% Lagranges Interpolation
% We calcualte lagrange interpolating point, and plot the polynomial

clc;
clear;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% part (a)

%given data point
x = [0,1,3];
y = [1,3,5];
l_x = length(x);

%intialization for plotting
x_plot = 0:0.1:3;
l = length(x_plot);
y_plot_1 = NaN(l,1);
y_plot_2 = NaN(l,1);

%pointer to keep track of split point
deg = 1;
sp = 1;
ep = deg + sp;

%calculating the interpolated values
for i=1:l
    % clalulting interpolated values using p1
    if x_plot(i)<=x(ep)
        y_plot_1(i) = p1(x(sp:ep),y(sp:ep), x_plot(i));
    else
        sp = ep;
        ep = sp + deg;
        y_plot_1(i) = p1(x(sp:ep),y(sp:ep), x_plot(i));
    end
    
    % clalulting interpolated values using p2
    y_plot_2(i) = p2(x,y,x_plot(i));
end

% Displaying the polynomials
fprintf("PART (a) \n\n")
fprintf("Printing the polynomial for P1(x)\n")
fprintf("====================================\n")
fprintf("For x=[0,1] \n"); str = p1_disp(x(1:2),y(1:2));
fprintf("\nFor x=[1,3] \n"); str = p1_disp(x(2:3),y(2:3));
fprintf("\n")

fprintf("\nPrinting the polynomial for P2(x)\n")
fprintf("====================================\n")
fprintf("For x=[0,1,3] \n"); str = p2_disp(x,y);
fprintf("\n")

%plotting
figure(1)
plot(x_plot, y_plot_1, 'b.-')
hold on
plot(x_plot, y_plot_2, 'g-')
scatter(x,y,'filled','r')
legend({'$p_1(x)$', '$p_2(x)$','Data points'}, 'Location','southeast','interpreter', 'latex','FontSize', 18)

xlabel("$x$",'interpreter', 'latex','FontSize', 18)
ylabel("$P_n(x)$",'interpreter', 'latex','FontSize', 18)
title("Part (a)",'FontSize', 20)
hold off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%part (b)

%given data points
x = [0,1,3,4,7];
y = [1,3,49,129,813];

%initializations for plotting
x_plot = 0:0.1:7;
l = length(x_plot);
y_plot_1 = NaN(l,1);
y_plot_2 = NaN(l,1);

%pointers to keep track of splitting the polynomials
deg1 = 1;
deg2 = 2;
sp1 = 1;
sp2 = 1;
ep1 = deg1 + sp1;
ep2 = deg2 + sp2;

%computinng interpolated values
for i=1:l
    % clalulting interpolated values using p1
    if x_plot(i)<=x(ep1)
        y_plot_1(i) = p1(x(sp1:ep1),y(sp1:ep1), x_plot(i));
    else
        sp1 = ep1;
        ep1 = sp1 + deg1;
        y_plot_1(i) = p1(x(sp1:ep1),y(sp1:ep1), x_plot(i));
    end
    
    % clalulting interpolated values using p2
    if x_plot(i)<=x(ep2)
        y_plot_2(i) = p2(x(sp2:ep2),y(sp2:ep2), x_plot(i));
    else
        sp2 = ep2;
        ep2 = sp2 + deg2;
        y_plot_2(i) = p2(x(sp2:ep2),y(sp2:ep2), x_plot(i));
    end

end

%printing the polynomials
fprintf("\n---------------------------------------------------\n")
fprintf("\nPART (b)\n\n")
fprintf("Printing the polynomial for P1(x)\n")
fprintf("====================================\n")
fprintf("For x=[0,1] \n"); str = p1_disp(x(1:2),y(1:2));
fprintf("\nFor x=[1,3] \n"); str = p1_disp(x(2:3),y(2:3));
fprintf("\nFor x=[3,4] \n"); str = p1_disp(x(3:4),y(3:4));
fprintf("\nFor x=[4,7] \n"); str = p1_disp(x(4:5),y(4:5));
fprintf("\n")
fprintf("\nPrinting the polynomial for P2(x)\n")
fprintf("====================================\n")
fprintf("For x=[0,1,3] \n"); str = p2_disp(x(1:3),y(1:3));
fprintf("\nFor x=[3,4,7] \n"); str = p2_disp(x(3:5),y(3:5));
fprintf("\n")

%plotting
figure(2)
plot(x_plot, y_plot_1, 'b.-')
hold on
plot(x_plot, y_plot_2, 'g-')
scatter(x,y,'filled','r')
legend({'$p_1(x)$', '$p_2(x)$','Data points'}, 'Location','northwest','interpreter', 'latex','FontSize', 18)

xlabel("$x$",'interpreter', 'latex','FontSize', 18)
ylabel("$P_n(x)$",'interpreter', 'latex','FontSize', 18)
title("Part (b)",'FontSize', 20)
hold off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%required functions
function val = p1(x,y, x_i)
    % Calulating P1(x) for x,y
    % x: set of input points, must be row vectors;
    % y: set of values of x, must be row vectors;
    
    c = ones(2,1);
    
    %calculating coefficients
    for i=1:2
        for j=1:2
            if j~=i
                c(i) = c(i)*(x_i - x(j))/(x(i) - x(j));
            end
        end
    end
    val = y*c;
end
function str = p1_disp(x,y)
    %function to display the polynomial
    c = ones(2,1);
    c_1 = ["", ""];
    str = "";
    
    %calculating coefficients
    for i=1:2
        for j=1:2
            if j~=i
                c(i) = c(i)/(x(i) - x(j));
                c_1(i) = c_1(i) + "(x-"+string(x(j))+")";
            end
            c(i) = c(i)*y(i);
        end
    end
    
    for i=1:2
        if i~=2
            str = str + "(" + string(c(i)) + c_1(i) + ")" + " + ";
        else 
            str = str + "(" + string(c(i)) + c_1(i) +")";
        end
    end
    fprintf("P1(x) for given x: %s", str)
end

function val = p2(x,y, x_i)
    % Calulating P2(x) for x,y
    % x: set of input points, must be row vectors;
    % y: set of values of x, must be row vectors;
    
    c = ones(3,1);
    
    %calculating coefficients
    for i=1:3
        for j=1:3
            if j~=i
                c(i) = c(i)*(x_i - x(j))/(x(i) - x(j));
            end
        end
    end
    val = y*c;
end
function str = p2_disp(x,y)
    %functoin to display the polynomials
    c = ones(3,1);
    c_1 = ["", "", ""];
    str = "";
    
    %calculating coefficients
    for i=1:3
        for j=1:3
            if j~=i
                c(i) = c(i)/(x(i) - x(j));
                c_1(i) = c_1(i) + "(x-"+string(x(j))+")";
            end
            c(i) = c(i)*y(i);
        end
    end
    
    for i=1:3
        if i~=3
            str = str + "(" + string(c(i)) + c_1(i)+ ")" + " + ";
        else 
            str = str + string(c(i)) + c_1(i);
        end
    end
    fprintf("P2(x) for given x: %s", str)
end