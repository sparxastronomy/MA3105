%% hermite interpolation
% This script performs the hermite interpolation for the given problem,
% We did this for Piece-wise Cubic Hermite interpolation. With a little bit
% of modification, the PCH founciton can be used for higher orders of
% hermite intepolation

clear;clc;

%% creating Data points for intepolation
x1 = linspace(-1,1,10);
x2 = linspace(-1,1,20);
x3 = linspace(-1,1,40);
x4 = linspace(-4,4,10);
y1 = exp(x1);
y2 = exp(x2);
y3 = exp(x3);


% getting actual value to compare the interpolation
xx = linspace(-1,1,120);
xx_4 = linspace(-4, 4, 120);
y_xx = exp(xx);

%% getting interpolated values 

y_x1 = PCH(x1, y1, y1, xx);
y_x2 = PCH(x2, y2, y2, xx);
y_x3 = PCH(x3, y3, y3, xx);
y_x4 = PCH(x4, sin(x4), cos(x4), xx_4);

%% Plotting for case 1
% figure porperties
ax = figure(1);
set(gcf,'Units','inches')
set(gcf, "Position",[0.1 0.1 13 8])
sgtitle("$x\in[-1,1]$, $f(x)=e^x$, Points=10", ...
    Interpreter="latex", FontSize=18)

%plotting interpolated data
Ax1 = subplot(2,1,1);
plot(xx, y_xx, DisplayName='$y = e^x$')
xlim([-1.05 1.05])
hold on
plot(xx', y_x1,"blue",'Marker','>',"MarkerEdgeColor",'black', ...
    "MarkerSize",4,"LineWidth",1, "DisplayName","Interpolated Data")
scatter(x1,y1,"filled","red","SizeData",90, ...
    'DisplayName','Input Data Points $(n=10)$')
hold off
legend(Interpreter="latex", Location="best", FontSize=14)
ylabel("$f(x)$", Interpreter="latex", FontSize=22)
PosVec = Ax1.Position;
Ax1.Position = PosVec+[0 -0.132 0 0.1];

% plotting errors
Ax2 = subplot(2,1,2);
plot(xx', y_xx' - y_x1, Marker="+",Color=[0.8500, 0.3250, 0.0980], ...
    LineWidth=2,DisplayName='$Error = y-y_{interpolated}$')
xlim([-1.05 1.05])
legend(Interpreter="latex", Location="best", FontSize=14)
PosVec = Ax2.Position;
Ax2.Position = PosVec+[0 0 0 -0.1];
xlabel("$x-values$", Interpreter="latex",FontSize=22)
ylabel("$Error$", Interpreter="latex",FontSize=20)

% exportgraphics(ax,"Case1.jpg",'Resolution',300)

%% Plotting for Case 2
% figure porperties
ax = figure(2);
set(gcf,'Units','inches')
set(gcf, "Position",[0.1 0.1 13 8])
sgtitle("$x\in[-1,1]$, $f(x)=e^x$, Points=20", ...
    Interpreter="latex", FontSize=18)

%plotting interpolated data
Ax1 = subplot(2,1,1);
plot(xx, y_xx, DisplayName='$y = e^x$')
xlim([-1.05 1.05])
hold on
plot(xx', y_x2,"blue",'Marker','>',"MarkerEdgeColor",'black', ...
    "MarkerSize",4,"LineWidth",1, "DisplayName","Interpolated Data")
scatter(x2,y2,"filled","red","SizeData",90, ...
    'DisplayName','Input Data Points $(n=20)$')
hold off
legend(Interpreter="latex", Location="best", FontSize=14)
ylabel("$f(x)$", Interpreter="latex", FontSize=22)
PosVec = Ax1.Position;
Ax1.Position = PosVec+[0 -0.132 0 0.1];

% plotting errors
Ax2 = subplot(2,1,2);
plot(xx', y_xx' - y_x2, Marker="+",Color=[0.8500, 0.3250, 0.0980], ...
    LineWidth=2,DisplayName='$Error = y-y_{interpolated}$')
xlim([-1.05 1.05])
legend(Interpreter="latex", Location="best", FontSize=14)
PosVec = Ax2.Position;
Ax2.Position = PosVec+[0 0 0 -0.1];
xlabel("$x-values$", Interpreter="latex",FontSize=22)
ylabel("$Error$", Interpreter="latex",FontSize=20)

% exportgraphics(ax,"Case2.jpg",'Resolution',300)

%% Plotting for Case 3
% figure porperties
ax = figure(3);
set(gcf,'Units','inches')
set(gcf, "Position",[0.1 0.1 13 8])
sgtitle("$x\in[-1,1]$, $f(x)=e^x$, Points=40", ...
    Interpreter="latex", FontSize=18)

%plotting interpolated data
Ax1 = subplot(2,1,1);
plot(xx, y_xx, DisplayName='$y = e^x$')
xlim([-1.05 1.05])
hold on
plot(xx', y_x3,"blue",'Marker','>',"MarkerEdgeColor",'black', ...
    "MarkerSize",4,"LineWidth",1, "DisplayName","Interpolated Data")
scatter(x3,y3,"filled","red","SizeData",90, ...
    'DisplayName','Input Data Points $(n=40)$')
hold off
legend(Interpreter="latex", Location="best", FontSize=14)
ylabel("$f(x)$", Interpreter="latex", FontSize=22)
PosVec = Ax1.Position;
Ax1.Position = PosVec+[0 -0.132 0 0.1];

% plotting errors
Ax2 = subplot(2,1,2);
plot(xx', y_xx' - y_x3, Marker="+",Color=[0.8500, 0.3250, 0.0980], ...
    LineWidth=2,DisplayName='$Error = y-y_{interpolated}$')
xlim([-1.05 1.05])
legend(Interpreter="latex", Location="best", FontSize=14)
PosVec = Ax2.Position;
Ax2.Position = PosVec+[0 0 0 -0.1];
xlabel("$x-values$", Interpreter="latex",FontSize=22)
ylabel("$Error$", Interpreter="latex",FontSize=20)

% exportgraphics(ax,"Case3.jpg",'Resolution',300)

%% Plotting for a sample case of sin x
% figure porperties
ax = figure(4);
set(gcf,'Units','inches')
set(gcf, "Position",[0.1 0.1 13 8])
sgtitle("$x\in[-4,4]$, $f(x)=sin(x)$, Points=10", ...
    Interpreter="latex", FontSize=18)

%plotting interpolated data
Ax1 = subplot(2,1,1);
plot(xx_4, sin(xx_4), DisplayName='$y = sin(x)$')
xlim([-4.05 4.05])
hold on
plot(xx_4', y_x4,"blue",'Marker','>',"MarkerEdgeColor",'black', ...
    "MarkerSize",4,"LineWidth",1, "DisplayName","Interpolated Data")
scatter(x4,sin(x4),"filled","red","SizeData",90, ...
    'DisplayName','Input Data Points $(n=10)$')
hold off
legend(Interpreter="latex",Location="best", FontSize=14)
ylabel("$f(x)$", Interpreter="latex", FontSize=22)
PosVec = Ax1.Position;
Ax1.Position = PosVec+[0 -0.132 0 0.1];

% plotting errors
Ax2 = subplot(2,1,2);
plot(xx_4', sin(xx_4)' - y_x4, Marker="+",Color=[0.8500, 0.3250, 0.0980], ...
    LineWidth=2,DisplayName='$Error = y-y_{interpolated}$')
xlim([-4.05 4.05])
legend(Interpreter="latex", Location="northwest", FontSize=14)
PosVec = Ax2.Position;
Ax2.Position = PosVec+[0 0 0 -0.1];
xlabel("$x-values$", Interpreter="latex",FontSize=22)
ylabel("$Error$", Interpreter="latex",FontSize=20)

% exportgraphics(ax,"Case4.jpg",'Resolution',300)


%% Functions for interpolation

% Function to do the piecewise hermite interpolation
function [yy] = PCH(x,y,y_der,xx)
    % Introduction
    %======================================================================
    % This function does piece wise cubic hermite interpolation
    % (x,y,y_der) are the data points to be provided to the algorithm   
    % where this are of the form (x, f(x), f'(x)).
    % 
    % 'xx' is the array of points to perform the interpolation
    %     
    %  x,y,y_der should be row vectors   
    %  
    % The function take two consicutive points from the array x
    % computes the coefficients for the hermite interpolation 
    % polynomial using divivded differnce method and then computes
    % the interpolated values for xx's lying between those two points.
    %======================================================================


    %% checking if the length of data points agrees
    if (length(x) ~= length(y)) || (length(x) ~= length(y_der))
        printf("Lenght of input points are different!!!")
        return
    end

    %% Initializing the array to store interpolated values
    yy = nan(length(xx), 1);
    yy_idx = 1; % index to keep track of points of interpolation

    for k = 1:length(x)-1
        %% Computing the coefficient for a set of interpolation points a,b
        coeff = div_diff(x(k:k+1), y(k:k+1), [y_der(k:k+1)]' );
        
        % creating z-array as in forward differnce table
        z = repelem(x(k:k+1),2); 

        if yy_idx>length(xx)
            break   % Additional check
        end
        
        % selecting points out of xx lying between a,b
        x_reduced = xx(xx>=x(k) & xx<=x(k+1));

        % Computing the values at interpolated point from the coefficients
        % calculated above
 
        for j=1:length(x_reduced)
            coeff_x = ones(1,4);
            for i = 2:4
                coeff_x(i) = coeff_x(i-1)*(x_reduced(j)-z(i-1));
            end

            %getting interpolated values at required points
            yy(yy_idx) = coeff*coeff_x' ;
            yy_idx = yy_idx+1;         
        end
    end


end

% Function to compute the divided differnce table for Hermite Intepolation
function coeff = div_diff(z,f_z, f_der)
    %% Introduction
    % computes divided diffeence table for hermite interpolation
    % z is the array nodes
    % f_z is the values at nodes
    % f_der is a matrix whose columns are the derivatives at the nodes,
    % where the first column is f', second column is f'' and so on.
    
    
    %% getting the number of points and order of derivatives provided
    [n_r, n_c] = size(f_der); 
    
    %% Preparing the z and f_z array for divided difference table
    z = repelem(z, n_c+1);
    f_z = repelem(f_z, n_c+1);
    
    %% initializing divided diffference array
    FD = nan(n_r*(n_c+1), 2*n_r);
    FD(:,1) = f_z;  % setting the first column
    
    %% Computing the divided difference
    for j=2:(2*n_r)
        der_idx = 0;  %derivative index
        for i=1:(n_r*(n_c+1) - j+1)
            % updating derivative index
            if rem(n_c + 1, i)==0
                der_idx = der_idx + 1;
            end

            %% Updating elements in the divided difference table
            % Checking it the next element should be derivitive or not
            if FD(i,j-1) == FD(i+1,j-1)
                FD(i,j) = f_der(der_idx, j-1)/(factorial(j-1));
            else
                % doining normal forward difference caclualtion
                FD(i,j) = (FD(i+1,j-1) - FD(i,j-1))/(z(i+j-1) - z(i));
            end
        end
    end
    % The required coeffieents for hermite interpolation would be the first
    % row of the forward differnece matrix
    coeff = FD(1,:);
end