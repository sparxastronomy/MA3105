% This script will compare the hermite intepolation techniqe to that of
% cubic spline interpolation technique for the given problem of e^x

clear;clc;

%% creating Data points for intepolation
x = linspace(-1,1,10);
y = exp(x);


% getting actual value to compare the interpolation
xx = linspace(-1,1,120);
y_xx = exp(xx);

%% getting interpolated values 

y_x = PCH(x, y, y, xx); %piecewise cubic hermite interpolation
y_xs = spline(x, y, xx); %cubic splie interploation

%% Plotting for Comparing
% figure porperties
ax = figure(1);
set(gcf,'Units','inches')
set(gcf, "Position",[0.1 0.1 13 8])
sgtitle("Comparing Hermite and Cubic Spline Interpolation (Points=10)", ...
    Interpreter="latex", FontSize=18)

%plotting interpolated data
Ax1 = subplot(2,1,1);
plot(xx, y_xx, DisplayName='$y = e^x$')
xlim([-1.05 1.05])
hold on
plot(xx', y_x,"blue",'Marker','>',"MarkerEdgeColor",'black', ...
    "MarkerSize",4,"LineWidth",1, ...
    "DisplayName","Interpolated Data (PCHI)")
plot(xx', y_xs,"blue",'Marker','.',"MarkerEdgeColor",'black', ...
    "MarkerSize",10,"LineWidth",1, ...
    "DisplayName","Interpolated Data (CubicSpline Interpolation)")
scatter(x,y,"filled","red","SizeData",90, ...
    'DisplayName','Input Data Points')
hold off
legend(Interpreter="latex", Location="northwest", FontSize=14)
ylabel("$f(x)$", Interpreter="latex", FontSize=22)
PosVec = Ax1.Position;
Ax1.Position = PosVec+[0 -0.132 0 0.1];

% plotting errors
Ax2 = subplot(2,1,2);
hold on
plot(xx', y_xx' - y_x, Marker="+",Color=[0.8500, 0.3250, 0.0980], ...
    LineWidth=2, ...
    DisplayName='$Error(PCHI) = y-y_{interpolated}$')
plot(xx', y_xx - y_xs, Marker="+",Color=[0.4500, 0.8250, 0.0980], ...
    LineWidth=2, ...
    DisplayName='$Error(Cubic Spline) = y-y_{interpolated}$')
hold off
xlim([-1.05 1.05])
legend(Interpreter="latex", Location="southwest", FontSize=14)
PosVec = Ax2.Position;
Ax2.Position = PosVec+[0 0 0 -0.1];
xlabel("$x-values$", Interpreter="latex",FontSize=22)
ylabel("$Error$", Interpreter="latex",FontSize=22)
%exportgraphics(ax,"Compare1.jpg",'Resolution',300)

%plotting differnce in error of 2 methods
ax = figure(2);
set(gcf,'Units','inches')
set(gcf, "Position",[0.1 0.1 10 4])
% sgtitle("Comparing Errors in Hermite and Cubic Spline Interpolation (Points=10)", ...
%     Interpreter="latex", FontSize=18)
plot(xx', (y_xx' - y_x)-(y_xx - y_xs)', ...
    Marker="+",Color=[0.3500, 0.3250, 0.6980], ...
    LineWidth=2, ...
    DisplayName='$Error(PCHI) - Error(CSI)$')
xlim([-1.05 1.05])

legend(Interpreter="latex", Location="north", FontSize=14)
xlabel("$x-values$", Interpreter="latex",FontSize=22)
ylabel("$Relative~~Difference$", Interpreter="latex",FontSize=18)
%exportgraphics(ax,"Compare2.jpg",'Resolution',300)



%% Functions for interpolation

% Function to do the piecewise hermite interpolation
function [yy] = PCH(x,y,y_der,xx)
    % Introduction
    %======================================================================
    % This function does piece wise cubic hermite interpolation
    % (x,y,y_der) are the data points to be provided to the algorithm   
    % where this are of the form (x, f(x), f'(x)).
    % 
    % 'xx' is the array of points to perform the interpolation
    %     
    %  x,y,y_der should be row vectors   
    %  
    % The function take two consicutive points from the array x
    % computes the coefficients for the hermite interpolation 
    % polynomial using divivded differnce method and then computes
    % the interpolated values for xx's lying between those two points.
    %======================================================================


    %% checking if the length of data points agrees
    if (length(x) ~= length(y)) || (length(x) ~= length(y_der))
        printf("Lenght of input points are different!!!")
        return
    end

    %% Initializing the array to store interpolated values
    yy = nan(length(xx), 1);
    yy_idx = 1; % index to keep track of points of interpolation

    for k = 1:length(x)-1
        %% Computing the coefficient for a set of interpolation points a,b
        coeff = div_diff(x(k:k+1), y(k:k+1), [y_der(k:k+1)]' );
        
        % creating z-array as in forward differnce table
        z = repelem(x(k:k+1),2); 

        if yy_idx>length(xx)
            break   % Additional check
        end
        
        % selecting points out of xx lying between a,b
        x_reduced = xx(xx>=x(k) & xx<=x(k+1));

        % Computing the values at interpolated point from the coefficients
        % calculated above
 
        for j=1:length(x_reduced)
            coeff_x = ones(1,4);
            for i = 2:4
                coeff_x(i) = coeff_x(i-1)*(x_reduced(j)-z(i-1));
            end

            %getting interpolated values at required points
            yy(yy_idx) = coeff*coeff_x' ;
            yy_idx = yy_idx+1;         
        end
    end


end

% Function to compute the divided differnce table for Hermite Intepolation
function coeff = div_diff(z,f_z, f_der)
    %% Introduction
    % computes divided diffeence table for hermite interpolation
    % z is the array nodes
    % f_z is the values at nodes
    % f_der is a matrix whose columns are the derivatives at the nodes,
    % where the first column is f', second column is f'' and so on.
    
    
    %% getting the number of points and order of derivatives provided
    [n_r, n_c] = size(f_der); 
    
    %% Preparing the z and f_z array for divided difference table
    z = repelem(z, n_c+1);
    f_z = repelem(f_z, n_c+1);
    
    %% initializing divided diffference array
    FD = nan(n_r*(n_c+1), 2*n_r);
    FD(:,1) = f_z;  % setting the first column
    
    %% Computing the divided difference
    for j=2:(2*n_r)
        der_idx = 0;  %derivative index
        for i=1:(n_r*(n_c+1) - j+1)
            % updating derivative index
            if rem(n_c + 1, i)==0
                der_idx = der_idx + 1;
            end

            %% Updating elements in the divided difference table
            % Checking it the next element should be derivitive or not
            if FD(i,j-1) == FD(i+1,j-1)
                FD(i,j) = f_der(der_idx, j-1)/(factorial(j-1));
            else
                % doining normal forward difference caclualtion
                FD(i,j) = (FD(i+1,j-1) - FD(i,j-1))/(z(i+j-1) - z(i));
            end
        end
    end
    % The required coeffieents for hermite interpolation would be the first
    % row of the forward differnece matrix
    coeff = FD(1,:);
end